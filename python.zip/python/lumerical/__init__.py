"""
Copyright (c) 2024 ANSYS, Inc.

This program is commercial software: you can use it under the terms of the
Ansys License Agreement as published by ANSYS, Inc.

Except as expressly permitted in the Ansys License Agreement, you may not
modify or redistribute this program.
"""